package com.phoneagent
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    const val MODEL = "gemini-3.6-flash"
    const val SYS = """You control an Android phone. Each turn you get the user's goal, past steps, and the current screen as a numbered list.
Reply with ONLY one JSON object, one action per turn:
{"action":"open_app","text":"app name"}
{"action":"tap","index":N}
{"action":"type","index":N,"text":"..."}  (index optional: uses focused field)
{"action":"scroll","text":"down|up"}
{"action":"back"} {"action":"home"}
{"action":"write_file","filename":"x.py","content":"full code"}  (for coding/editing requests)
{"action":"done","text":"short result in user's language"}
Use done when the goal is finished. Reply in the user's language (Hindi/Hinglish ok)."""

    fun ask(ctx: Context, prompt: String): String {
        val sp = ctx.getSharedPreferences("p", 0)
        val key = (sp.getString("k", "") ?: "").trim()
        val model = (sp.getString("m", "") ?: "").trim().ifEmpty { MODEL }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("Gemini ${c.responseCode}: ${txt.take(200)}")
        return JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
