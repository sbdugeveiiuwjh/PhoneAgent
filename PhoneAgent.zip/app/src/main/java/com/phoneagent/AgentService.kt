package com.phoneagent
import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File

class AgentService : AccessibilityService() {
    companion object { var inst: AgentService? = null }
    private val h = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var sr: SpeechRecognizer? = null
    private val nodes = ArrayList<AccessibilityNodeInfo>()

    override fun onServiceConnected() { inst = this; addBubble() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        inst = null
        bubble?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    private fun addBubble() {
        val d = resources.displayMetrics.density
        val t = TextView(this)
        t.text = "🎤"; t.textSize = 24f; t.gravity = Gravity.CENTER
        t.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC6200EE")) }
        t.setOnClickListener { listen() }
        val lp = WindowManager.LayoutParams((56 * d).toInt(), (56 * d).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(t, lp)
        bubble = t
    }

    fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle app kholke Mic permission do"); return
        }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val s = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                toast("Suna: $s"); Agent.run(this@AgentService, s)
            }
            override fun onError(e: Int) { toast("Awaaz samajh nahi aayi ($e)") }
            override fun onReadyForSpeech(p: Bundle?) { toast("Boliye...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        })
    }

    fun screen(): String {
        nodes.clear()
        val sb = StringBuilder()
        val root = rootInActiveWindow ?: return "(screen empty)"
        fun walk(n: AccessibilityNodeInfo) {
            val t = (n.text ?: n.contentDescription)?.toString()
            if ((n.isClickable || n.isEditable || !t.isNullOrBlank()) && nodes.size < 120) {
                sb.append("[${nodes.size}] ${n.className?.toString()?.substringAfterLast('.')} \"${t ?: ""}\"")
                if (n.isClickable) sb.append(" click"); if (n.isEditable) sb.append(" edit")
                sb.append("\n"); nodes.add(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return sb.toString().take(6000)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    fun act(a: JSONObject): String = try {
        val dm = resources.displayMetrics
        when (a.optString("action")) {
            "open_app" -> {
                val q = a.optString("text").lowercase(); val pm = packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val app = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                if (app == null) "app not found" else {
                    startActivity(pm.getLaunchIntentForPackage(app.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "opened"
                }
            }
            "tap" -> {
                val n = nodes.getOrNull(a.optInt("index", -1)) ?: return "bad index"
                var c: AccessibilityNodeInfo? = n
                while (c != null && !c.isClickable) c = c.parent
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "clicked" else {
                    val r = Rect(); n.getBoundsInScreen(r); gesture(r.exactCenterX(), r.exactCenterY(), r.exactCenterX(), r.exactCenterY(), 50); "tapped"
                }
            }
            "type" -> {
                val n = nodes.getOrNull(a.optInt("index", -1)) ?: findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "no field"
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text")) }
                if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "typed" else "type failed"
            }
            "scroll" -> {
                val w = dm.widthPixels / 2f; val hh = dm.heightPixels.toFloat()
                if (a.optString("text") == "up") gesture(w, hh * 0.3f, w, hh * 0.7f, 300) else gesture(w, hh * 0.7f, w, hh * 0.3f, 300)
                "scrolled"
            }
            "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "back" }
            "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "home" }
            "write_file" -> {
                val dir = File(getExternalFilesDir(null), "agent_code"); dir.mkdirs()
                val f = File(dir, File(a.optString("filename", "code.txt")).name)
                f.writeText(a.optString("content")); toast("Saved: ${f.absolutePath}"); "saved ${f.name}"
            }
            else -> "unknown action"
        }
    } catch (e: Exception) { "error ${e.message}" }
}
