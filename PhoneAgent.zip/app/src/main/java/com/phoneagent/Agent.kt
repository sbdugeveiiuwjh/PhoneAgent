package com.phoneagent
import org.json.JSONObject

object Agent {
    @Volatile var busy = false
    fun run(svc: AgentService, goal: String) {
        if (busy) { svc.toast("Agent busy hai"); return }
        busy = true
        Thread {
            val hist = StringBuilder()
            try {
                for (step in 1..10) {
                    val screen = svc.screen()
                    val a = JSONObject(Gemini.ask(svc, "Goal: $goal\nPast steps:\n$hist\nScreen:\n$screen"))
                    val act = a.optString("action")
                    if (act == "done") { svc.toast(a.optString("text", "Ho gaya")); break }
                    svc.toast("$step: $act")
                    hist.append("$step. $a -> ${svc.act(a)}\n")
                    Thread.sleep(1500)
                }
            } catch (e: Exception) { svc.toast("Error: ${e.message}") }
            busy = false
        }.start()
    }
}
